exports.LOG_LEVELS = process.env.LOG_LEVELS.split(',').map((item) => item.trim());
exports.REGION = process.env.REGION;
