#!/bin/bash
npm run usbeta-vs-static-code-analysis-report
