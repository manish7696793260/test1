#!/bin/bash
npm run usprd-vs-static-code-analysis-report
