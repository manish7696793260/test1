#!/bin/bash
npm run usqa-vs-static-code-analysis-report
