#!/bin/bash
npm run usstg-vs-static-code-analysis-report
