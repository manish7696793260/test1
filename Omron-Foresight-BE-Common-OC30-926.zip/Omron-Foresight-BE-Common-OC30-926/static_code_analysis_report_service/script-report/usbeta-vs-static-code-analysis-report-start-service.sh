#!/bin/bash
service usbeta-vs-static-code-analysis-report stop &&
sleep 2
service usbeta-vs-static-code-analysis-report start
