#!/bin/bash
chmod +x /data/usprd-vs-static-code-analysis-report/static_code_analysis_report_service/script-report/usprd-vs-static-code-analysis-report-start-service.sh &&
chmod +x /data/usprd-vs-static-code-analysis-report/static_code_analysis_report_service/usprd-vs-static-code-analysis-report-script.sh
