#!/bin/bash
chmod +x /data/usbeta-vs-static-code-analysis-report/static_code_analysis_report_service/script-report/usbeta-vs-static-code-analysis-report-start-service.sh &&
chmod +x /data/usbeta-vs-static-code-analysis-report/static_code_analysis_report_service/usbeta-vs-static-code-analysis-report-script.sh
