#!/bin/bash
chmod +x /data/usqa-vs-static-code-analysis-report/static_code_analysis_report_service/script-report/usqa-vs-static-code-analysis-report-start-service.sh &&
chmod +x /data/usqa-vs-static-code-analysis-report/static_code_analysis_report_service/usqa-vs-static-code-analysis-report-script.sh
