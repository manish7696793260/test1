#!/bin/bash
service usdev-vs-static-code-analysis-report stop &&
sleep 2
service usdev-vs-static-code-analysis-report start
