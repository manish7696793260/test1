#!/bin/bash
service usqa-vs-static-code-analysis-report stop &&
sleep 2
service usqa-vs-static-code-analysis-report start
