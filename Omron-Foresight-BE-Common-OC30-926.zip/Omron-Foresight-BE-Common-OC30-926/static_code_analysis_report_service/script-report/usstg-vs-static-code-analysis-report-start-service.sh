#!/bin/bash
service usstg-vs-static-code-analysis-report stop &&
sleep 2
service usstg-vs-static-code-analysis-report start
