#!/bin/bash
service usprd-vs-static-code-analysis-report stop &&
sleep 2
service usprd-vs-static-code-analysis-report start
