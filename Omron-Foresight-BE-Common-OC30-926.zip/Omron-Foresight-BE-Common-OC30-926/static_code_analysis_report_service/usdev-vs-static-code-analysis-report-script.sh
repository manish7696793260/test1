#!/bin/bash
npm run usdev-vs-static-code-analysis-report
