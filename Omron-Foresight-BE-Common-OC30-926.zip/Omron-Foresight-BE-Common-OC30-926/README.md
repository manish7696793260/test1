# omron-foresight-be-common
Common resources for VS and OFC
