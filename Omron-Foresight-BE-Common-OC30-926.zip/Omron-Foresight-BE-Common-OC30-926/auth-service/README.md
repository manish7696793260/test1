# omron-common-auth-service module
<!--BEGIN STABILITY BANNER-->

---

![Stability: Stable](https://img.shields.io/badge/cfn--resources-stable-success.svg?style=for-the-badge)

---
<!--END STABILITY BANNER-->

| **Reference Documentation**:| <span style="font-weight: normal">https://omronhealthcare-ohi.atlassian.net/wiki/spaces/VFC/pages/2380005377/VS+-+HCO</span>|
|:-------------|:-------------|
<div style="height:8px"></div>

| **Language**     | **Package**        |
|:-------------|-----------------|
|Node.js|`@https://github.com/OmronHealthCare-OHI/omron-foresight-be-common/auth-service`|

## Overview

This is a common micro service which will be used across the Omron application related to Authentication