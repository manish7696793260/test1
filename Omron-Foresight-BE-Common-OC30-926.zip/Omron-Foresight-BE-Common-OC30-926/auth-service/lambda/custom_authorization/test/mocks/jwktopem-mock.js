const jwkToPem = () => {
	return 'kid';
};

module.exports = jwkToPem;
