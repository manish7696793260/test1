#!/bin/bash
rm /var/www/html/index.html